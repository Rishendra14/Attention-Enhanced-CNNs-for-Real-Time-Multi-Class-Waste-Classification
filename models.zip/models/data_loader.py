import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader

def load_data():
    # Paths to your dataset folders
    train_dir = "data/train"
    val_dir = "data/validation"
    test_dir = "data/test"

    # Define transforms
    train_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(10),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
    ])

    val_test_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
    ])

    # Load datasets
    train_dataset = datasets.ImageFolder(root=train_dir, transform=train_transform)
    val_dataset = datasets.ImageFolder(root=val_dir, transform=val_test_transform)
    test_dataset = datasets.ImageFolder(root=test_dir, transform=val_test_transform)

    # Create DataLoaders
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True, num_workers=0)  # num_workers=0 for Windows
    val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False, num_workers=0)

    # Class names
    class_names = train_dataset.classes
    print(f"Classes: {class_names}")
    print(f"Train images: {len(train_dataset)}, Validation images: {len(val_dataset)}, Test images: {len(test_dataset)}")

    # Example of getting a batch
    images, labels = next(iter(train_loader))
    print(f"Image batch shape: {images.size()}")
    print(f"Label batch shape: {labels.size()}")

    return train_loader, val_loader, test_loader, class_names

if __name__ == "__main__":  # ✅ Required on Windows
    load_data()
